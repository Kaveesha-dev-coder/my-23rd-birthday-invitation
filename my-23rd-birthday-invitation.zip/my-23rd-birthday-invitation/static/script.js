
// A little birthday greeting 🎀
console.log("Welcome to my 23rd Birthday! 💗");
